# ESP32-S3 BLE Wi-Fi 配网首轮联调交付包

交付状态：`FIRMWARE_IMPLEMENTED_FIRST_INTEGRATION`。

本包可以提交给 Android APP 工程师开展 Security 2 真机联调。它不代表量产就绪：逐设备 PoP、factory NVS 注入、生产二维码/领用链路、Secure Boot、Flash Encryption、NVS Encryption 和云端绑定协议仍未完成。

## 阅读顺序

1. `01-app-firmware-handoff.md`：双方必须按此实现的冻结协议。
2. `05-provisioning-contract.json`：机器可读契约，Provider 常量应以它为准。
3. `02-first-integration-runbook.md`：首轮真机操作和结果判定。
4. `06-simulator-guide.md`：Mock/Real 模拟器使用说明。
5. `00-audit-report.md`：已修复问题、遗留风险和可交付结论。
6. `03-architecture.md`、`04-change-inventory.md`、`08-acceptance-matrix.md`：固件结构、修改清单和验收矩阵。
7. `07-flash-approval.md`：构建与烧录边界。

## 冻结值

| 项目 | 值 |
| --- | --- |
| 芯片 / SDK | ESP32-S3 / ESP-IDF `v6.0` |
| ESP-IDF commit | `662a3be354759d9487bf4b1a629fadb766cb1800` |
| 配网组件 | `espressif/network_provisioning` `1.2.4` |
| 组件 commit | `2de4980640bbe3d2d69473d7251640039e185b92` |
| BLE Host | NimBLE |
| Service UUID | `0000ffff-0000-1000-8000-00805f9b34fb` |
| 广播名 | `PROV_` + STA MAC 后三字节大写十六进制 |
| 安全 | protocomm Security 2，SRP6a + AES-GCM，不降级 |
| capabilities | `wifi_prov`、`wifi_scan` |
| 自定义 endpoint | `device-info` |
| 成功标准 | `IP_EVENT_STA_GOT_IP` / `prov-config=connected` |
| 传输 | 仅 BLE，不支持 SoftAP fallback |

当前开发设备：设备 ID `NX-3927-2693-9288`，广播名 `PROV_1467C4`。开发联调 PoP 写在机器契约中，仅用于首轮联调，禁止用于生产。

## 模拟器

`simulator/` 包含网页、Bridge、二维码解析、离线 jsQR、依赖文件和测试。Mock 模式验证 APP 状态机；Real 模式复用工程锁定的 Espressif `esp_prov`、protobuf 和 Security 2 实现连接真实设备。

从本目录启动：

```powershell
cd simulator
.\start-bridge.ps1
```

打开 `http://127.0.0.1:8765/simulator/`。Bridge 仅绑定回环地址，不暴露仓库文件，不记录 PoP 或 Wi-Fi 密码，并串行执行 BLE 发现、设备 Wi-Fi 扫描和配网。

## 不包含的内容

- 不包含 `sdkconfig`、运行日志、缓存、`__pycache__` 或本地 Wi-Fi/云端凭据。
- 不包含固件 `.bin`；固件镜像可能包含本地开发配置，不属于 APP 对接交付物。
- 不包含量产密钥和每设备 PoP 数据库。
- 本轮没有烧录。只有用户明确确认后才允许执行烧录，详见 `07-flash-approval.md`。
