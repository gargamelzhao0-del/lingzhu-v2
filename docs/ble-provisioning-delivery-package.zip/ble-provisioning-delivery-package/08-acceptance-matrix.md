# 首轮联调验收矩阵

| 项目 | 当前状态 | 发布要求 |
| --- | --- | --- |
| ESP-IDF 6.0 + network_provisioning 1.2.4 构建 | 通过 | 保持版本锁定 |
| NimBLE 广播 UUID/名称 | 历史真机通过 | Android 再验证 |
| Security 2 正确 PoP | 模拟器/历史真机通过 | Android 再验证 |
| 错误 PoP | 历史真机通过 | APP 映射 `SECURITY_AUTH_FAILED` |
| `device-info` UID 校验 | 模拟器/历史真机通过 | 不匹配时禁止下发 Wi-Fi |
| 设备 `prov-scan` | 历史真机通过 | APP 串行刷新、不得并发配网 |
| 正确 Wi-Fi | 两次历史真机通过 | Android 至少 20 次稳定性 |
| 错误密码 | 历史真机通过 | `WIFI_AUTH_FAILED` 且窗口内可重试 |
| SSID 不存在 | 历史真机通过 | `NETWORK_NOT_FOUND` |
| 成功标准 | 代码/模拟器通过 | 仅 `GOT_IP`，不等云端/屏幕 |
| 成功后 BLE 15 秒 | 历史真机通过 | Android 查询后主动释放 |
| 300 秒窗口 + 末端宽限 | 代码通过 | 故障注入待测 |
| 本地重配网按钮 | 历史真机通过 | 新镜像烧录后回归 |
| Android 断连恢复 | 未联合验证 | 必测 |
| 纯 WPA3-only | 未验证 | 若产品要求则补测 |
| SoftAP fallback | 明确不支持 | APP 不显示 fallback |
| 生产逐设备 PoP/安全启动 | 未实现 | 量产 P0 阻塞 |
| 云端 claim/绑定/解绑 | 未实现 | 独立协议后续交付 |

只有 Android 联合验收、20 次稳定性和所有 P0 生产项完成后，才能把契约状态升级为 `INTEGRATION_VERIFIED` 或生产状态。
