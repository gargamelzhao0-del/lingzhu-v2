# BLE 配网架构和状态机

## 模块边界

```mermaid
flowchart LR
    APP["Android Provider / 模拟器"] -->|"NimBLE GATT"| NP["network_provisioning 1.2.4"]
    NP --> PC["protocomm Security 2"]
    NP --> WIFI["ESP-IDF Wi-Fi STA"]
    FW["nuwax_provision_main"] --> NP
    FW --> INFO["device-info"]
    FW --> UID["nuwax_device_uid"]
    WIFI --> WM["wifi_manager 凭据导入"]
    UI["Device QR / BLE 按钮"] --> FW
    UID --> CLOUD["hello.device_id"]
```

- `network_provisioning` 拥有 BLE provisioning、官方 protobuf endpoints 和 Wi-Fi 配置状态机。
- `nuwax_provision_main` 配置 Service UUID、Security 2、capabilities、窗口、错误诊断和 `device-info`。
- `wifi_manager` 只在成功后导入驱动保存的 STA 配置，不与 provisioning manager 并发控制 Wi-Fi。
- UI 只提供二维码和需要物理在场的重配网入口。

## 时序

```mermaid
sequenceDiagram
    participant A as APP
    participant B as BLE/protocomm
    participant F as 固件
    participant W as Wi-Fi STA
    A->>B: 扫描 UUID + PROV_名称
    A->>B: proto-ver
    B-->>A: sec_ver=2, wifi_prov, wifi_scan
    A->>B: Security 2(username, PoP)
    A->>F: device-info {}
    F-->>A: serialNumber + 诊断
    A->>F: prov-scan（可重复，串行）
    F-->>A: 设备可见 Wi-Fi
    A->>F: prov-config set + apply
    F->>W: 连接 2.4 GHz AP
    loop 最长 35 秒
        A->>F: prov-config status
        F-->>A: connecting / failed / connected
    end
    W-->>F: IP_EVENT_STA_GOT_IP
    F-->>A: connected
    Note over A,F: 成功后保留 15 秒查询窗口
```

## 状态机

- `IDLE_CONFIGURED`：已配网，不广播 BLE。
- `ADVERTISING`：首次未配网或本地重配网重启，300 秒。
- `SECURE_SESSION`：Security 2 已建立，可读身份和扫描。
- `APPLYING`：凭据已接收，最多观察 30 秒；APP 最多等 35 秒。
- `FAILED_RETRYABLE`：已映射失败，窗口仍有效时可重新建 session/重试。
- `SUCCESS_HOLD`：已 GOT_IP，保留 15 秒。
- `STOPPED`：释放 BLE；失败需重新进入配网，成功进入正常业务启动。

设备 Wi-Fi 扫描和配网不能并发。模拟器/APP 停止后续扫描，但不强行中断已经发送给设备的 `prov-scan`；当前扫描完成并断开后再发起配网，避免同一 BLE 外设被两个操作争用。
