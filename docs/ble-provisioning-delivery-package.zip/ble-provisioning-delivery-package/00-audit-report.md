# BLE 配网交付前审计报告

审计日期：2026-07-23。结论：固件和模拟器满足首轮 Android Provider 真机联调要求，可以提交；存在量产阻塞项，不能标记为 `INTEGRATION_VERIFIED` 或生产就绪。

## 审计范围

- 固件：`main/nuwax_provision_new`、Wi-Fi 管理、启动集成、Device 菜单、设备二维码、稳定设备 ID、云端 hello 设备 ID。
- 配置：ESP-IDF/组件锁定、NimBLE、protocomm Security 2、网络扫描、内存配置。
- 模拟器：二维码、BLE 发现、Security 2、`device-info`、`prov-scan`、`prov-config`、状态机、错误映射、静态文件和本机 HTTP 边界。
- 文档：APP 原始需求、APP 仓库对接入口、机器契约与实际代码逐项比对。

## 本轮已修复

| 问题 | 修复 |
| --- | --- |
| 生产 identity-only QR 无 PoP 时，即使用户补录 PoP，前端仍错误禁用扫描/配网 | 只有二维码实际携带 PoP 时才要求完全相等；不含 PoP 时允许受控补录 |
| 契约把已成为必需流程的设备 Wi-Fi 扫描标成非必需 | `networkScanRequired` 改为 `true` |
| Bridge 只绑定 loopback，但未阻止恶意网页对本机端口发起简单 POST | 增加 Host、Origin、`application/json` 校验和 CSP 等安全响应头；设备发现改为 POST |
| BLE 操作可能被并发任务或长时间异常占用 | BLE 发现、Wi-Fi 扫描、配网共用操作锁，任务数有上限，单操作设置 90 秒保护超时 |
| eFuse MAC 读取失败后忽略 fallback 返回值，极端情况下可能产生重复 UID | 两种 MAC 读取都失败或 SHA-256 失败时直接返回错误，不生成弱身份 |
| 固件二维码使用字符串拼接，配置字符可能破坏 JSON | 使用 cJSON 结构化生成并检查长度/内存；`device-info` 同时校验请求是 JSON 对象 |
| QR 前端仅检查 `PROV_` 前缀 | 改为严格匹配 `PROV_[0-9A-F]{6}`，并校验 username/PoP UTF-8 长度 |
| Bridge 曾以仓库根目录作为静态目录 | 静态目录限制为模拟器目录，`sdkconfig`、源码、构建和日志不能经 HTTP 读取 |

## 技术纠错

APP 仓库当前入口文档把 `prov-ctrl` 描述为配网终态权威来源，这是错误的。ESP-IDF `network_provisioning` 的 Wi-Fi set/apply/status 都在 `prov-config`；`prov-ctrl` 只用于 reset/reprovision 控制。本交付包和机器契约已统一为：

- 状态权威来源：`prov-config`。
- 控制 endpoint：`prov-ctrl`，本期 APP 不通过它远程清除设备凭据。
- 固件成功标准：`IP_EVENT_STA_GOT_IP`，APP 看到 `connected` 即成功，不等待屏幕 Wi-Fi 图标或云端上线。

## 遗留风险

### P0：量产阻塞

- 当前 `CONFIG_NUWAX_PROVISION_SEC2_DEV_MODE=y`，固定开发 PoP 会被所有开发设备共用，禁止量产。
- `nuwax_factory` 逐设备 salt/verifier 注入、PoP 管理、Secure Boot、Flash Encryption、NVS Encryption 尚未交付。
- 生产固件只保存 salt/verifier，设备屏幕二维码不含明文 PoP。若 APP 只扫描屏幕二维码而没有产线标签或云端受控凭据来源，Security 2 无法完成。
- 云端“设备领用/绑定/解绑/所有权转移”协议不属于当前 BLE 配网代码，尚未实现。云端身份必须使用 `device-info.serialNumber`，不能使用 BLE 地址或广播名。
- 产线不得克隆已经包含 `nuwax_uid` 缓存的整片 NVS；每台设备必须由本机 eFuse 派生或写入经唯一性校验的工厂序列号。
- 本地 `sdkconfig` 含机器专用开发配置，不能提交给 APP 或进入交付包。

### P1：发布前联调

- Android Provider 的真实 Security 2、蓝牙权限、断连恢复和后台/前台切换尚未联合验收。
- 300 秒窗口末端的 30 秒 active-attempt grace 需要故障注入验证。
- 需要至少连续 20 次配网、失败后重试和重配网稳定性测试。
- 纯 WPA3-only AP 尚未验证；已验证的是 2.4 GHz WPA2/WPA3 transition AP。
- 广播名只有 24 bit MAC 后缀，极低概率出现附近设备同名；Security 2 和 `device-info` 会阻止错误下发，但 APP 应明确提示重试，量产可评估增加非敏感 identity hint。

### P2：明确边界

- 当前 UID 展示格式只有 48 bit 哈希截断。现阶段可用于联调，量产应由产线唯一性注册表校验，或切换为工厂写入的更长不可变序列号。
- 模拟器和首轮契约要求非空 Wi-Fi 密码，未冻结开放网络配网。若产品需要开放网络，应单独扩展并验收。

## 已验证证据

- ESP-IDF 6.0 完整构建通过；镜像 `0x323070`，应用分区约 34% 空闲。
- 本轮镜像 SHA-256：`823B921DD2CC71D9B5CB26C69FD7314902FD32FF06E852E6F32CDACFB4817997`。
- Bridge 单元测试 11 项通过；二维码测试 16 项通过；Python/JavaScript 语法检查通过。
- 模拟器 Mock 成功流程到达 `SUCCESS`；桌面 `1440x900` 和移动 `390x844` 无水平溢出，浏览器控制台无错误。
- Bridge 静态隔离、同源限制、JSON 限制和契约接口已做 HTTP 验证。
- 历史真机验证：Security 2、身份校验、设备 Wi-Fi 扫描、两次正确凭据配网分别约 `14.051 s`、`13.232 s` 到达 `SUCCESS`。

本轮只构建，没有执行烧录；新镜像的真机验证必须等待用户确认烧录后进行。
